﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrowdTwist
{
    class Program
    {
        static void Main(string[] args)
        {
            Animation animation = new Animation();
            string[] results = animation.animate(2, "LRLR.LRLR");

            for (int iCounter = 0; iCounter < results.Length; iCounter++)
            {
                Console.WriteLine(results[iCounter]);
            }

            Console.ReadLine();
        }
    }

    class Animation
    {
        public string[] animate(int speed, string init)
        {
            List<string> result = new List<string>();

            if (speed > 10 || speed < 1) throw new Exception("The speed must be between 1 and 10.");
            if (init.Length > 50 || init.Length < 1) throw new Exception("The init string must be between 1 and 50 characters in length.");
            if (init.ToUpper().IndexOf('R') == -1 && init.ToUpper().IndexOf('L') == -1) {
                result.Add(init);
                return result.ToArray();
            }

            string currentString = init.ToUpper();
            result.Add(currentString);

            int arrayLength = init.Length;

            int counter = 0;

            while (currentString.IndexOf('R') != -1 && currentString.IndexOf('L') != -1)
            {
                List<int> leftIndexes = new List<int>();
                List<int> rightIndexes = new List<int>();
                List<char> newString = new List<char>();

                for (int iCounter = 0; iCounter < currentString.Length; iCounter++)
                {
                    if (currentString[iCounter] == 'L')
                    {
                        if ((iCounter - speed) >= 0) { 
                            leftIndexes.Add(iCounter - speed);
                        }
                    }
                    if (currentString[(currentString.Length - 1) - iCounter] == 'R')
                    {
                        if ((((currentString.Length - 1) - iCounter) + speed) <= (currentString.Length - 1))
                        {
                            rightIndexes.Add(((currentString.Length - 1) - iCounter) + speed);
                        }
                    }
                }

                for (int iCounter = 0; iCounter < currentString.Length; iCounter++)
                {
                    if (leftIndexes.Contains(iCounter))
                    {
                        newString.Add('L');
                    }
                    if (rightIndexes.Contains(iCounter))
                    {
                        newString.Add('R');
                    }
                    if (!leftIndexes.Contains(iCounter) && !rightIndexes.Contains(iCounter)) 
                    {
                        newString.Add('.');
                    }
                }

                currentString = string.Join("", newString.ToArray());

                if (counter > 0)
                {
                    result.Add(currentString.Replace('R', 'X').Replace('L', 'X'));
                }
                counter++;
            }

            return result.ToArray();
        }
    }
}



















